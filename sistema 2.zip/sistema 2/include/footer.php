<script src="./assets/script.js"></script>
</body>
</html>